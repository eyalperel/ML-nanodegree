The python version used in this project: 2.7.12
libraries used: sklearn, pandas, numpy, datetime, matplotlib.pyplot

IMPORTANT: this project uses a dataset of the raw data (as described in the code and in the report) in the form of a csv file that is attached to this submission.
this file should be in the same folder as the python code in order for the code to run properly.
